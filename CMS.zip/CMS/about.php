<div id="id03" class="modal">
  
  <form class="modal-content animate">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avtar.JPEG"  style="width:100px;height:100px;" alt="Avatar" class="avatar">
    </div>

	
	
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Academic CMS Portal</h5>
      </div>
      <div class="modal-body">
        Stay connected with our Academic content management portal. And Get Updated with all sort of informations.
      </div>
    </div>
  </form>
</div>