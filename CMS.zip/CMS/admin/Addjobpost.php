<?php
extract($_POST);
if(isset($save)){
	
	$title=mysqli_real_escape_string($conn,$_POST["title"]);
	$Company=mysqli_real_escape_string($conn,$_POST["Company"]);
	$Salary=mysqli_real_escape_string($conn,$_POST["Salary"]);
$Location=mysqli_real_escape_string($conn,$_POST["Location"]);
	$category=mysqli_real_escape_string($conn,$_POST["category"]);
$Details=mysqli_real_escape_string($conn,$_POST["Details"]);
$jobCat=$_POST['category'];
date_default_timezone_set('Asia/Kolkata');
$datetime = date('m/d/Y h:i:s a', time());
$author=$uname;
if(empty($title) || empty($Company)  || empty($category) || empty($Details) || empty($Location) || empty($Salary))
{
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>All Fields must be Filled out</b>
</div>

";


}
elseif(strlen($title)<2){
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Title should be at least two character long</b>
</div>

";

}
else{
$execute=mysqli_query($conn,"insert into jobpost(jobSubject,jobCompany,jobSalary,jobLocation,datetime,jobCat,Details,jobPostBy)values('$title','$Company','$Salary','$Location','$datetime','$jobCat','$Details','$author')");
if($execute){
$err.=  "
<div class='alert alert-success'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Post Added successfully</b>
</div>

";


}else{
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>OOPS! something went wrong</b>
</div>

";

}
}

//echo $datetime;

}



?>
<div class="row">
		 <div class="col-md-1"></div>
		 <div class="col-md-10">

		 <div class="panel panel-info">
<div class="panel-heading">Post a Job / Enter Job Description</div>
<div class="panel-body">
<form method="post" enctype="multipart/form-data">
<div class="row">

		 <br><br>
<div class="col-md-12" id="login_msg">
<?php echo($err) ?>
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Job Title </b></label>
<input type="text" placeholder="Add Title for post" name="title" id="title" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Job Company  </b></label>
<input type="text" placeholder="Company" name="Company" id="Company" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Job Salary </b></label>
<input type="text" placeholder="Salary" name="Salary" id="Salary" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Location</b></label>
<input type="text" placeholder="Location" name="Location" id="Location" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Select Category For the Job</b></label>

<select class="form-control" id="categoryselect" name="category">
<?php
$Viewquery="select * from jobcategory order by datetime desc";
$execute=mysqli_query($conn,$Viewquery);
while($datarows=mysqli_fetch_array($execute)){
$jobCat=$datarows["jobcatid"];
$categoryname=$datarows["jobcatname"];
?>
<option value="<?php echo($jobCat) ?>"><?php echo $categoryname;?></option>
<?php } ?>
</select>

</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label for="Details"><b>Details:</b></label>
<textarea class="form-control" name="Details" id="Details"></textarea>
</div>
</div>
<p><br/></p>
<div class="row">
<div class="col-md-12">

<input name="save" type="submit" value="Create Post" class="btn btn-lg btn-success btn-block">
</div>
</div>




</div>
</form>

		 
		 </div>
		 <div class="col-md-1"></div>
		 </div>
		 </div>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>			 