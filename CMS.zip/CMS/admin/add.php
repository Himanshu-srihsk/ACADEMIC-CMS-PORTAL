<h1 align='center'> ADD-ON FEATURES</h1>
<div class="row">
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Add User</h5>
        <p class="card-text">Add New User (Student (usertype 1)/ parents (usertype 2)/ faculty (usertype 3)/ admin (usertype 4)</p>
        <a href="index.php?page=new_user" class="btn btn-primary">Add user</a>
      </div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"> Add/Create jobs </h5>
        <p class="card-text">Create new post in job category </p>
        <a href="index.php?page=Addjobpost" class="btn btn-primary">Create job Post</a>
      </div>
    </div>
  </div>
  
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Add job category in job section</h5>
        <p class="card-text">Add new category for job </p>
        <a href="index.php?page=addjobcategory" class="btn btn-primary">Add Job Category</a>
      </div>
    </div>
  </div>
  <br/><br/>
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Job Portal</h5>
        <p class="card-text">Add new category for job </p>
        <a href="index.php?page=jobportal" class="btn btn-primary">
		<i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;Job Portal&nbsp;</a>
      </div>
    </div>
  </div>
  
  <br><br>
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">View Profile</h5>
        <p class="card-text">See profile of user and its post </p>
        <a href="index.php?page=view_profile" class="btn btn-primary">
		<i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;View Profile&nbsp;</a>
      </div>
    </div>
  </div>
  <br><br>
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Events&nbsp;</h5>
        <p class="card-text">Update any eventsents</p>
        <a href="index.php?page=events" class="btn btn-primary">
		<i class="fa fa-archive" aria-hidden="true"></i>&nbsp;Events&nbsp;</a>
      </div>
    </div>
  </div>
    <br><br>
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Group Discussion &nbsp;</h5>
        <p class="card-text">Discussion form</p>
        <a href="../groupdiscussionadmin.php" class="btn btn-primary">
		<i class="fa fa-archive" aria-hidden="true"></i>&nbsp;Group Discusssion&nbsp;</a>
      </div>
    </div>
  </div>
  <br><br>
  <div class="col-sm-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Update Password &nbsp;</h5>
        <p class="card-text">Update Your  Password here</p>
        <a href="index.php?page=update_password" class="btn btn-primary">
		<i class="fa fa-archive" aria-hidden="true"></i>&nbsp;Update Password &nbsp;</a>
      </div>
    </div>
  </div>
</div>