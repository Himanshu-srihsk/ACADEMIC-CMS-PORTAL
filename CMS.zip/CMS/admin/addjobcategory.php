<?php
extract($_POST);
session_start();
if(isset($Submit)){
$category=mysqli_real_escape_string($conn,$_POST["category"]);
$description=mysqli_real_escape_string($conn,$_POST["description"]);
date_default_timezone_set('Asia/Kolkata');
$datetime = date('m/d/Y h:i:s a', time());
	//echo $datetime;
	//$Creator=$_SESSION["admin"];
	$Creator=$uname;
	if(empty($category) || empty($description) )
{
	$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>All Fields must be Filled out</b>
</div>

";
}
elseif(strlen($category)>120){
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Too Long Name for Category</b>
</div>

";
}
$sql=mysqli_query($conn,"select * from category where name='$category'");

$r=mysqli_num_rows($sql);

if($r==true)
{
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>$category  already Exists</b>
</div>

";
}

if($err == null){
$execute=mysqli_query($conn,"insert into jobcategory(datetime,jobcatname,jobcatdescription 
,postedBy )values('$datetime','$category','$description','$Creator')");
if($execute){
	$err.=  "
<div class='alert alert-success'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Category Added successfully</b>
</div>

";
}else{
	$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>OOPS! something went wrong</b>
</div>

";
}
}	
}



?>
<script>
function Deletejobcategory(id)
	{
		if(confirm("You want to delete this record ?"))
		{
		window.location.href="delete_job_category.php?id="+id;
		}
	}
</script>
<div class="col-md-1"></div>
<div class="col-md-10">
<h1>Manage JOB Section</h1>
<?php echo($err) ?>
<form method="post">
<fieldset>
<div class="form-group">
<label for="categoryname"><span class="fieldinfo">Job Category:</span></label>
<input type="text"  class="form-control" name="category" id="categoryname"placeholder="Name">
</div>
<div class="form-group">
<label for="categoryname"><span class="fieldinfo">JobCatDescription:</span></label>
<input type="text"  class="form-control" name="description" id="description"placeholder="JobCatDescription">
</div>
<input class="btn btn-success btn-block" type="Submit" name="Submit" value="Add New JOB Category">
</fieldset>
</form>
<br><br>
<div class="table-responsive">
<table class="table table-striped table-hover">
<tr>
<th>Sr No</th>
<th> date & time</th>
<th>Job Category</Th>
<th>Job Description</Th>
<th>Created By</th> 
<th>Action</th>
</tr>
<?php
$Viewquery="select * from jobcategory order by datetime desc";
$execute=mysqli_query($conn,$Viewquery);
$srno=0;
while($datarows=mysqli_fetch_array($execute)){
$id=$datarows["jobcatid"];
$datetime=$datarows["datetime"];
$categoryname=$datarows["jobcatname"];
$description=$datarows["jobcatdescription"];
$creatorname=$datarows["postedBy"];
$srno++;
?>
<tr>
<td><?php echo $srno; ?></td>
<td><?php echo $datetime; ?></td>
<td><?php echo $categoryname; ?></td>
<td><?php echo $description; ?></td>
<td><?php echo $creatorname ; ?></td>
<td>
<a href="javascript:Deletejobcategory('<?php echo $id; ?>')" style='color:Red'><span class='glyphicon glyphicon-trash'></span></a>
</td>
</tr>
<?php }?>
</table>


</div>

</div><!--Ending of main area-->
<div class="col-md-1"></div>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>	