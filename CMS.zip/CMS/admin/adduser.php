<?php
require('../connection.php');
extract($_POST);
if(isset($save)){
$uname=$_POST['uname'];
$email=$_POST['email'];
$pass=($_POST['pass']);
$mob=$_POST['mob'];
$gen=$_POST['gen'];
//$hob=$_POST['hob'];
$stuid=$_POST['stuid'];
$mm=$_POST['mm'];
$dd=$_POST['dd'];
$yy=$_POST['yy'];
$utype=$_POST['utyp'];

$name="/^[a-zA-Z\\s]*$/";
$emailValidation="/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z]{2,4})$/";
$number="/^[0-9]+$/";
if(empty($uname)||empty($email)||empty($pass)||empty($mob)||empty($gen)
	||empty($stuid)||empty($mm)||empty($dd)||empty($yy) ||empty($utype))
{
$err.= "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Please fill all fields</b>
</div>

";
}

else{
if(!preg_match($name,$uname)){
$err.= "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>$uname is not valid</b>
</div>
";

}	
if(!preg_match($emailValidation,$email)){
$err.="
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>$email is not valid</b>
</div>
";

}
if(strlen($pass)<5){
$err.="
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>password is weak</b>
</div>
";


}

if(!preg_match($number,$mob)){
$err.="
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>Mobile number $mobile is not valid</b>
</div>
";

}
if(strlen($mob)==10){

}else{
$err.="
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>Mobile number should be 10 digit long</b>
</div>
";
}
$sql=mysqli_query($conn,"select * from user where email='$email'");
$sql2=mysqli_query($conn,"select * from user where Student_ID='$stuid'");
$sql3=mysqli_query($conn,"select * from user where mobile='$mob'");
$r=mysqli_num_rows($sql);
$r2=mysqli_num_rows($sql2);
$r3=mysqli_num_rows($sql3);

if($r==true)
{
$err.= "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>Email Address already Exists try another one</b>
</div>
";

}
else if($r2==true)
{
$err.="
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>This Student Id already Exists try another one</b>
</div>
";

}
else if($r3==true)
{
$err.= "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>This Mobile No already Exists try another one</b>
</div>
";

}

else if($err == null)
{
//dob
$dob=$yy."-".$mm."-".$dd;

//hobbies
$hob=implode(",",$hob);

//image
$imageName=$_FILES['img']['name'];


//encrypt your password
$pass=md5($pass);
//$utyp='STUDENT';
$query="insert into user(name,email,pass,mobile,gender,hobbies,image,dob,Student_id,usertype)values('$uname','$email','$pass','$mob','$gen','$hob','$imageName','$dob','$stuid','$utype')";
mysqli_query($conn,$query);

//upload image
$image=$_FILES['img']['name'];
if($image==null){$image="avtar.JPEG";}
mkdir("../images/$email");
move_uploaded_file($_FILES['img']['tmp_name'],"../images/$email/$image");


//$err="<font color='blue'>Registration successfull !!</font>";

$err.= "
<div class='alert alert-primary'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<b>Registration successfull </b>
</div>
";


}	

}
}

?>
		 <div class="row">
		 <div class="col-md-1"></div>
		 <div class="col-md-10">

		 <div class="panel panel-info">
<div class="panel-heading">Add New User</div>
<div class="panel-body">
<form method="post" enctype="multipart/form-data">
<div class="row">

		 <br><br>
<div class="col-md-12" id="login_msg">
<?php echo($err) ?>
</div>

<div class="col-md-12">
<label><b>User Type</b></label>
<Td >
					<select name="utyp" class="form-control" >
					<option value=" ">--- Select a user type---</option>
				
					  <option value="1">STUDENT</option>
					  <option value="2">PARENT</option>
					  <option value="3">FACULTY</option>
					  <option value="4">ADMIN</option>
					  
					</select>
					</td>
</div>
</div>
<br><div class="row">
<div class="col-md-12">
<label><b>Student ID/Employee ID</b></label>
<input type="text" placeholder="Student ID " name="stuid" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Your Name</b></label>
<input type="text" placeholder="Student Name" name="uname" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Your Email</b></label>
<input type="email" placeholder="Student E-mail" name="email" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Your Password </b></label>
<input type="password" placeholder="Enter Password" name="pass" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Your Mobile No.</b></label>
<input type="text" placeholder="Student phone number" name="mob" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
  <tr>
					<td><b>Select Your Gender</b></td><br>
					<Td>
				Male <input type="radio" name="gen" value="m" />   
				Female  <input type="radio" name="gen" value="f"/>  
					</td>
				</tr>
	  <br>
	  <tr>
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<tr>
					<td><b>Choose Your Hobbies</b></td><br>
					<Td>
					<input value="reading" type="checkbox" name="hob[]"/>  Reading <br/>
					<input value="singin" type="checkbox" name="hob[]"/>   Singing <br/>
					<input value="playing" type="checkbox" name="hob[]"/>  Playing <br/>
					<input value="Dancing" type="checkbox" name="hob[]"/>  Dancing <br/>
					<input value="others" type="checkbox" name="hob[]"/>  Others<br/>
					
					</td>
				</tr>
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<tr>
					<td><label ><b>Upload  Your Image</b></label> </td>
					<Td><input class="form-control" type="file" name="img" /></td><br/>
				</tr>
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">

<tr>
					<td><b>Date of Birth</b></td>
					<Td>
					<select name="yy">
					<option value="">Year</option>
					<?php
					for($i=1950;$i<=2016;$i++)
					{
					echo "<option>".$i."</option>";
					}
					?>

					</select>

					<select name="mm"><!--required -->
					<option value="">Month</option>
					<?php
					for($i=1;$i<=12;$i++)
					{
					echo "<option>".$i."</option>";
					}
					?>

					</select>


					<select name="dd">
					<option value="">Date</option>
					<?php
					for($i=1;$i<=31;$i++)
					{
					echo "<option>".$i."</option>";
					}
					?>

					</select>

					</td>
				</tr>

	   
	   <br><br>
</div>
</div>

<p><br/></p>
<div class="row">
<div class="col-md-12">

<input name="save" type="submit" value="Save" class="btn btn-lg btn-success btn-block">
</div>
</div>


</div>
</form>

		 
		 </div>
		 <div class="col-md-1"></div>
		 </div>
		 </div>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>			 