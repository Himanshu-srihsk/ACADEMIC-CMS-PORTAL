<?php 
include('../connection.php');
$cid=$_GET['id'];
$q=mysqli_query($conn,"update comments set status='ON' where id='$cid'");
header('location:index.php?page=comments');
?>