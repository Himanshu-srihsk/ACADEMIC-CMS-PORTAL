<?php

extract($_POST);
session_start();
if(isset($Submit)){
$category=mysqli_real_escape_string($conn,$_POST["category"]);
date_default_timezone_set('Asia/Kolkata');
$datetime = date('m/d/Y h:i:s a', time());
	//echo $datetime;
	//$Creator=$_SESSION["admin"];
	$Creator=$uname;
	if(empty($category))
{
	$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>All Fields must be Filled out</b>
</div>

";
}
elseif(strlen($category)>99){
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Too Long Name for Category</b>
</div>

";
}
$sql=mysqli_query($conn,"select * from category where name='$category'");

$r=mysqli_num_rows($sql);

if($r==true)
{
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>$category  already Exists</b>
</div>

";
}

if($err == null){
$execute=mysqli_query($conn,"insert into category(datetime,name,creatorname)values('$datetime','$category','$Creator')");
if($execute){
	$err.=  "
<div class='alert alert-success'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Category Added successfully</b>
</div>

";
}else{
	$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>OOPS! something went wrong</b>
</div>

";
}
}	
}



?>
<script>
function Deletecategory(id)
	{
		
		if(confirm("You want to delete this record ?"))
		{
			if(<?php echo $_SESSION['usertype']; ?> == 3){
				window.location.href="delete_category_teacher.php?id="+id;
			}else{
		window.location.href="delete_category.php?id="+id;
			}
		}
	}
</script>
<div class="col-md-2"></div>
<div class="col-md-8">
<h1>Manage Categories</h1>
<?php echo($err) ?>
<form method="post">
<fieldset>
<div class="form-group">
<label for="categoryname"><span class="fieldinfo">Name:</span></label>
<input type="text"  class="form-control" name="category" id="categoryname"placeholder="Name">
</div>
<input class="btn btn-success btn-block" type="Submit" name="Submit" value="Add New Category">
</fieldset>


</form>
<br><br>
<div class="table-responsive">
<table class="table table-striped table-hover">
<tr>
<th>Sr No</th>
<th> Date & time</th>
<th>Category Name</Th>
<th>Creator Name</th> 
<th>Action</th>
</tr>
<?php
$Viewquery="select * from category order by datetime desc";
$execute=mysqli_query($conn,$Viewquery);
$srno=0;
while($datarows=mysqli_fetch_array($execute)){
$id=$datarows["id"];
$datetime=$datarows["datetime"];
$categoryname=$datarows["name"];
$creatorname=$datarows["creatorname"];
$srno++;
?>
<tr>
<td><?php echo $srno; ?></td>
<td><?php echo $datetime; ?></td>
<td><?php echo $categoryname; ?></td>
<td><?php echo $creatorname ; ?></td>
<td>
<a href="javascript:Deletecategory('<?php echo $id; ?>')" style='color:Red'><span class='glyphicon glyphicon-trash'></span></a>
</td>
</tr>
<?php }?>
</table>


</div>

</div><!--Ending of main area-->
<div class="col-md-2"></div>