<?php
$q=mysqli_query($conn,"select * from comments where status='OFF' order by id desc");
$r=mysqli_num_rows($q);
if($r == 0)
{
echo "<h2 style='color:red'>No any comments exists !!!</h2>";
}
else
{
?>
<script>
	function Deletecomment(id)
	{
		if(confirm("You want to delete this record ?"))
		{
		window.location.href="delete_comment.php?id="+id;
		}
	}
	
	function Approvecomment(id)
	{
		if(confirm("Are you sure to approve this user ?"))
		{
		window.location.href="approve_comment.php?id="+id;
		}
	}
	function disapprovecomment(id)
	{
		if(confirm("Are you sure to approve this user ?"))
		{
		window.location.href="disapprove_comment.php?id="+id;
		}
	}
</script>
<h2 style="color:#00FFCC">Unapproved Comments</h2>
<div class="table-responsive">
<table class="table table-striped table-hover">
    <thead>
      <tr class="success">
<th>No.</th>
<th>Commented By</th>
<th>Date</th>
<th>Comment</th>
<th>Approve Comment</th>
<th>Delete Comment</th>
<th>Details</th>
</tr>
    </thead>
    <tbody>
     <?php 
	 $i=1;
	 while($row=mysqli_fetch_assoc($q)){
		 
	echo "<Tr>";
echo "<td>".$i."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['datetime']."</td>";
echo "<td>".$row['comment']."</td>";	 	
?>
<Td>
<a href="javascript:Approvecomment('<?php echo $row['id']; ?>')" style='color:green'><span class='glyphicon glyphicon-ok-circle'></span></a>&nbsp;&nbsp;&nbsp;
</td>

<Td>
<a href="javascript:Deletecomment('<?php echo $row['id']; ?>')" style='color:Red'><span class='glyphicon glyphicon-trash'></span></a>
</td>


<?php

echo "<Td>
	<a href='index.php?page=fullpostadmin&post_id=".$row['adminpanel_id']."'><span class='btn btn-primary'>Live Preview</span>
	</a></td>"; 
echo "</Tr>";
$i++;	 
?>
	 
	 <?php } ?>
    </tbody>
  </table>
   <?php } ?>
  </div>
  

<?php
$q=mysqli_query($conn,"select * from comments where status='ON' order by id desc");
$r=mysqli_num_rows($q);
if($r == 0)
{
echo "<h2 style='color:red'>No any comments exists !!!</h2>";
}
else
{
?>  
  
  <h2 style="color:#00FFCC">Approved Comments</h2>
<div class="table-responsive">
<table class="table table-striped table-hover">
    <thead>
      <tr class="success">
<th>No.</th>
<th>Commented By</th>
<th>Date</th>
<th>Comment</th>
<th>Approved By </th>
<th>Revert Approve</th>
<th>Delete Comment</th>
<th>Details</th>
</tr>
    </thead>
    <tbody>
     <?php 
	 $i=1;
	 while($row=mysqli_fetch_assoc($q)){
		 
	echo "<Tr>";
echo "<td>".$i."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['datetime']."</td>";
echo "<td>".$row['comment']."</td>";
echo "<td>".$uname."</td>";	 	
?>
<Td>
<a href="javascript:disapprovecomment('<?php echo $row['id']; ?>')" style='color:green'><span class='glyphicon glyphicon-ok-circle'></span></a>&nbsp;&nbsp;&nbsp;
</td>

<Td>
<a href="javascript:Deletecomment('<?php echo $row['id']; ?>')" style='color:Red'><span class='glyphicon glyphicon-trash'></span></a>
</td>


<?php

echo "<Td>
	<a href='index.php?page=fullpostadmin&post_id=".$row['adminpanel_id']."'><span class='btn btn-primary'>Live Preview</span>
	</a></td>"; 
echo "</Tr>";
$i++;	 
?>
	 
	 <?php } ?>
    </tbody>
  </table>
  <?php } ?>
  </div>
  	<script>
	/*
	$(document).ready(function(){
setInterval(function(){
window.location.reload()
},10000);

})*/

	</script>