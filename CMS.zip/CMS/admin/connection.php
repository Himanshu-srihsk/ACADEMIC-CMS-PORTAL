<?php
global $conn;
$conn=mysqli_connect("localhost","root","master1234","project");
?>