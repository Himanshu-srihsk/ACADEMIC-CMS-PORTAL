<?php 
include('../connection.php');
$cid=$_GET['id'];
$q=mysqli_query($conn,"delete from comments where id='$cid'");
header('location:index.php?page=comments');
?>