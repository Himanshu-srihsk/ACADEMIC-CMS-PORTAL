<?php 
include('connection.php');
$nid=$_GET['id'];
$q=mysqli_query($conn,"delete from jobcategory where jobcatid='$nid'");
header('location:index.php?page=addjobcategory');
?>