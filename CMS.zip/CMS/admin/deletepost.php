<?php 
include('../connection.php');
$pid=$_GET['id'];
$q=mysqli_query($conn,"delete from adminpanel where id='$pid'");
header('location:index.php?page=notification');
?>