<?php 
include('connection.php');
session_start();

$user=$_SESSION['user'];
$eid=$_GET['id'];
$q=mysqli_query($conn,"insert into attendevent(semail,eventid)values('$user','$eid')");
//header('location:index.php?page=events');
?>
<script>window.history.go(-1);</script>