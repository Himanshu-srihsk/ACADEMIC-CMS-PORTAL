<?php
	require_once("../connection.php");
	session_start();
	//extract($_POST);
	if(isset($_POST["login"]))
	{
		
	//echo "ho";	
$email=mysqli_real_escape_string($conn,$_POST["email"]);
$password=md5($_POST["password"]);

$sql=mysqli_query($conn,"select * from user where email='$email' and pass='$password' AND usertype='4' AND opt='1'");//AND opt='1'

$r=mysqli_num_rows($sql);

if($r==true)
{
$_SESSION['user']=$email;
mysqli_query($conn,"update user set status='1' where email='$email'");
header('location:index.php');
}

else
{
$err=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Access Denied (wrong credential)</b>
</div>

";
}
	
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <title>College Social Network</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	 <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
</head>

<body>
<br><br><br>
    	 <div class="container-fluid">
		 
		 <div class="row">
		 <div class="col-md-2"></div>

<div class="col-md-2"></div>
	</div>
		 
		 <div class="row">
		 <div class="col-md-4"></div>
		 <div class="col-md-4">
		 <div class="panel panel-info">
<div class="panel-heading">Admin Login Form</div>
<div class="panel-body">
<form method="post">
<div class="row">
<div class="col-md-12">
<input type="text" class="form-control" id="email" name="email" placeholder="Email">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">

<input type="password" class="form-control" id="password" name="password" placeholder="password">
</div>
</div>

<p><br/></p>
<div class="row">
<div class="col-md-12">

<input name="login" type="submit" value="Login" class="btn btn-lg btn-success btn-block">
</div>
</div>
<br><br>
<div class="col-md-12" id="login_msg">
<?php echo($err) ?>
</div>

</div>
</form>

		 
		 </div>
		 <div class="col-md-4"></div>
		 </div>
		 </div></div>
	
</body>
</html>