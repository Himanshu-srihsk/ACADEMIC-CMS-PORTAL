<script>
	function Deletepost(id)
	{
		if(confirm("Are you sure to delete this record ?"))
		{
		window.location.href="deletepost.php?id="+id;
		}
	}
</script>

<?php
$q=mysqli_query($conn,"select * from adminpanel ORDER BY datetime DESC");
$r=mysqli_num_rows($q);
if(!$r)
{
echo "<h2 style='color:red'>No any Notice found in this query !!!</h2>";
}
else{
?>
<h2 style="color:#00FFCC">All Notice by user type</h2>
<table class="table table-striped table-hover">
	<thead><tr>
		<th colspan="10"><a href="index.php?page=addnewpost">Add new post</a></th>
	</tr>
	
	<Tr class="success">
		<th>Sr.No</th>
		<th>Title</th>
		<th>Author</th>
		<th>category</th>
		<th>User type</th>
		<th>Date</th>
		<th>Details</th>
		<th>Delete</th>
		<th>Update</th>
		
	</Tr>
	</thead>
		<tbody>
		<?php
		$i=1;
		while($row=mysqli_fetch_assoc($q)){
			
echo "<Tr>";
echo "<td>".$i."</td>";
echo "<td>".$row['title']."</td>";
echo "<td>".$row['author']."</td>";
echo "<td>".$row['category']."</td>";
echo "<td>".$row['userAccess']."</td>";
echo "<td>".$row['datetime']."</td>";
		
		
		?>
		<?php echo "<Td>
	<a href='index.php?page=fullpostadmin&post_id=".$row['id']."'><span class='btn btn-primary'>Live Preview</span>
	</a></td>"; ?>
		
		
		<Td>
		<a href="javascript:Deletepost('<?php echo $row['id']; ?>')" style='color:Red'><span class='glyphicon glyphicon-trash'></span></a>
		</td>
	
		<?php 
echo "<Td><a href='index.php?page=updatepost&post_id=".$row['id']."' style='color:green'><span class='glyphicon glyphicon-edit'></span></a></td>";

$i++;

?>
	<?php 
	echo "</Tr>";
	?>	
		
		<?php } ?>
		</tbody>
</table>
<?php } ?>