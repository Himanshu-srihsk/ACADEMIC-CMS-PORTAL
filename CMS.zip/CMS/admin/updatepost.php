<?php
include('../connection.php');
extract($_POST);
if(isset($save)){
	
	$title=mysqli_real_escape_string($conn,$_POST["title"]);
$category=mysqli_real_escape_string($conn,$_POST["category"]);
$post=mysqli_real_escape_string($conn,$_POST["post"]);
date_default_timezone_set('Asia/Kolkata');
$datetime = date('m/d/Y h:i:s a', time());
$author=$uname;
$userAccess=$_POST['user'];

$image=$_FILES["image"]["name"];
$path="../Upload/".basename($_FILES["image"]["name"]);

if(empty($title) || empty($userAccess)  || empty($category) || empty($post) || empty($image))
{
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>All Fields must be Filled out</b>
</div>

";
}
elseif(strlen($title)<2){
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Title should be at least two character long</b>
</div>

";

}
else{
	$Editfromurl=$_GET['post_id'];
$execute=mysqli_query($conn,"update adminpanel set datetime='$datetime',title='$title',category='$category',userAccess='$userAccess',image='$image',post='$post' where id='$Editfromurl'");
move_uploaded_file($image=$_FILES["image"]["tmp_name"],$path);
if($execute){
$err.=  "
<div class='alert alert-success'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Post updated successfully</b>
</div>

";


}else{
$err.=  "
<div class='alert alert-warning'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>OOPS! something went wrong</b>
</div>

";

}
}

//echo $datetime;

}
?>
<div class="row">
		 <div class="col-md-1"></div>
		 <div class="col-md-10">

		 <div class="panel panel-info">
<div class="panel-heading">Edit Post </div>
<div class="panel-body">
<form method="post" enctype="multipart/form-data">
<div class="row">

		 <br><br>
<div class="col-md-12" id="login_msg">
<?php echo($err) ?>
</div>

 <?php
 $searchqueryparameter=$_GET['post_id'];
 $query="select * from adminpanel where id='$searchqueryparameter'";
 $execute=mysqli_query($conn,$query);
 while($datarows=mysqli_fetch_array($execute)){
$titleupdate=$datarows["title"];
$usertypeupdate=$datarows["userAccess"];
$categoryupdate=$datarows["category"];
 $imageupdate=$datarows["image"];
 $postupdate=$datarows["post"];
 
 }
 ?>
 
<div class="col-md-12">
<label for="categoryselect"><span class="fieldinfo">Existing User Type:</span></label>
<?php
echo $usertypeupdate ?><br>
<label><b>Choose User Type:</b></label>
<Td >
					<select name="user" class="form-control">
					<option value=" ">--- Select a user type---</option>
					
					  <option value="1">STUDENT (Level-1)</option>
					  <option value="2">PARENTS (Level-2)</option>
					  <option value="3">FACULTY (Level-3)</option>
					  <option value="4">ADMIN (Level-4)</option>
					  <option value="5">ALL USER / GENERAL NOTICE (Level-5)</option>
					</select>
					</td>
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label><b>Title </b></label>
<input type="text" placeholder="Add Title for post" name="title" id="title" value="<?php echo $titleupdate;?>" class="form-control">
</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<label for="categoryselect"><span class="fieldinfo">Existing Category:</span></label>
<?php
echo $categoryupdate ?>
<br>
<label><b>Choose Category: </b></label>

<select class="form-control" id="categoryselect" name="category">
<?php
$Viewquery="select * from category order by datetime desc";
$execute=mysqli_query($conn,$Viewquery);
while($datarows=mysqli_fetch_array($execute)){
$id=$datarows["id"];
$categoryname=$datarows["name"];
?>
<option><?php echo $categoryname ;?>
<?php } ?>
</select>

</div>
</div>
<br>
<div class="row">
<div class="col-md-12">
<tr><td><label for="imageselect"><span class="fieldinfo">Existing Image:</span></label>
<img src="Upload/<?php echo $imageupdate; ?> " width=100px; height=50px;></td></tr>
<br>
<tr>
				<td><label><b>Select Banner:</b></label></td>
          <td><input type="file" class="form-control" name="image" id="imageselect"></td>
				</tr>
</div>
</div>

<div class="row">
<div class="col-md-12">
<label for="postarea"><b>Details:</b></label>
<textarea class="form-control" name="post" id="postarea">
<?php
echo $postupdate;
?>
</textarea>
</div>
</div>
<p><br/></p>
<div class="row">
<div class="col-md-12">

<input name="save" type="submit" value="Edit Post" class="btn btn-lg btn-success btn-block">
</div>
</div>




</div>
</form>

		 
		 </div>
		 <div class="col-md-1"></div>
		 </div>
		 </div>